from flask import render_template
from flask import Flask
from flask import abort

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/checkout/<int:planoid>')
def checkout(planoid):

	if planoid == 1:
		plano = "Individual"
		valor = 15
	elif planoid == 2:
		plano = "Familia"
		valor = 25
	else:
		abort(404)

	return render_template('checkout.html',plano=plano,valor=valor)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')